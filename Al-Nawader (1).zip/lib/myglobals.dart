library myglobals;

import 'package:purshases/utiles.dart';

String email="-1";
String name="-1";
String access_token="-1";
String mobile_number="-1";
String user_id="-1";
String country='-1';
String image='';
String mytokens='';
String lastmessage='';
DateTime lastdate=DateTime.now();
List<maincateg> myads=[];
bool login=false;