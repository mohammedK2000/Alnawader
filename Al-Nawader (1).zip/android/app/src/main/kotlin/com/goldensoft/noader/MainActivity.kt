package com.goldensoft.noader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
